import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import sys

#read data from csv file unrecognizedSchools.csv obtained from https://data.gov.in/resources/unrecognised-schools-rural-areas-having-primary-upper-primary-classes-and-enrolment-them

df=pd.read_csv(sys.argv[1])
df1=df[['STATE/U.T.','Number of Unrecognised Schools']]
matplotlib.rcParams.update({'font.size': 10})
w = 3
nitems = len(df1['Number of Unrecognised Schools'])
x_axis = np.arange(0, nitems*w, w)    

fig, ax = plt.subplots(1)
ax.bar(x_axis,df1['Number of Unrecognised Schools'], width=w, align='center')
ax.set_xticks(x_axis);
ax.set_xticklabels(df1['STATE/U.T.'], rotation=90);
plt.xlabel("State/UT")

plt.ylabel("No. of unrecognized schools")
plt.title("No. of unrecognized schools by states")
plt.show()
