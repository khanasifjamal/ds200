import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv file haryanarain.csv obtained from https://data.gov.in/resources/district-wise-average-annual-rainfall-haryana-1966-2012
df=pd.read_csv(sys.argv[1])
df1=df[['District','2010','2012']]

plt.scatter(df1[:-1]['2010'],df1[:-1]['2012'],color='#dd12dd',label='District')
#specifying labels

plt.xlabel("2010 avg annual rainfall")

plt.ylabel("2012 avg annual rainfall")
plt.title("Change in avg annual rainfall 2010 vs 2012 in Haryana districts")
#enable legend

plt.legend()

plt.show()
