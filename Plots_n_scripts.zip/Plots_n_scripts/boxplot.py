import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv file moneyord.csv obtained from https://data.gov.in/resources/total-number-and-amount-money-orders-india-during-2000-01-2010-11 

df=pd.read_csv(sys.argv[1])

df1=df[['2009-10','2010-11','2011-12']]
df1[:-1].boxplot()
plt.ylabel("Number of Money Orders Issued and Paid (in lakhs)")
plt.xlabel("Year")
plt.title("Money orders issued")
plt.legend()
plt.show()
